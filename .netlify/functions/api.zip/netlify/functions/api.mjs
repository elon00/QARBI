
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/api.mts
import { GoogleGenAI } from "@google/genai";
import crypto from "crypto";
var api_default = async (req) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/\.netlify\/functions\/api/, "").replace(/^\/api/, "");
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }
  if (path === "/health" || path === "" || path === "/") {
    return new Response(
      JSON.stringify({
        status: "ok",
        network: "Arbitrum Sepolia",
        chainId: 421614,
        stylusEngine: "active",
        pqcVersion: "ML-DSA-65 (Dilithium3)",
        timestamp: Date.now()
      }),
      { status: 200, headers }
    );
  }
  if (path === "/crypto/pqc-generate" && req.method === "POST") {
    const mockPubKeyBytes = crypto.randomBytes(1952);
    const pqcCommitmentHash = "0x" + crypto.createHash("sha3-256").update(mockPubKeyBytes).digest("hex");
    const ephemeralWallet = "0x" + crypto.randomBytes(20).toString("hex");
    return new Response(
      JSON.stringify({
        success: true,
        algorithm: "ML-DSA-65 (NIST FIPS 204)",
        publicKeyBytesLength: 1952,
        publicKeyPreview: "0x" + mockPubKeyBytes.slice(0, 16).toString("hex") + "..." + mockPubKeyBytes.slice(-16).toString("hex"),
        pqcCommitmentHash,
        delegatedSessionWallet: ephemeralWallet,
        attestationSignature: "0x" + crypto.randomBytes(65).toString("hex"),
        generatedAt: (/* @__PURE__ */ new Date()).toISOString()
      }),
      { status: 200, headers }
    );
  }
  if (path === "/gemini/plan-task" && req.method === "POST") {
    try {
      const body = await req.json();
      const { prompt, agentContext } = body;
      const apiKey = process.env.GEMINI_API_KEY;
      if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
        const ai = new GoogleGenAI({ apiKey });
        const systemPrompt = `You are the Qarbi Autonomous Agent Orchestrator on Arbitrum Sepolia.
Decompose the user prompt into an on-chain action with $QARBI bounty and return strict JSON with fields:
taskTitle, taskDescription, suggestedArchetype, estimatedGasUnits, rewardQarbi, policyVerification (isWithinSingleTxLimit, whitelistedTarget, securityRisk, riskAnalysis).`;
        const response = await ai.models.generateContent({
          model: "gemini-2.0-flash",
          contents: [{ role: "user", parts: [{ text: `${systemPrompt}
User Prompt: ${prompt}` }] }],
          config: { responseMimeType: "application/json" }
        });
        const parsed = JSON.parse(response.text || "{}");
        return new Response(JSON.stringify({ success: true, plan: parsed }), { status: 200, headers });
      }
    } catch {
    }
    return new Response(
      JSON.stringify({
        success: true,
        plan: {
          taskTitle: `Execute Autonomous Task`,
          taskDescription: `Decomposed and scheduled on Arbitrum Sepolia.`,
          suggestedArchetype: "RESEARCHER",
          estimatedGasUnits: 4120,
          rewardQarbi: 15,
          policyVerification: {
            isWithinSingleTxLimit: true,
            whitelistedTarget: "0x5FbDB2315678afecb367f032d93F642f64180aa3",
            securityRisk: "LOW",
            riskAnalysis: "Whitelisted Arbitrum contract interaction within spending caps."
          }
        }
      }),
      { status: 200, headers }
    );
  }
  return new Response(JSON.stringify({ error: "Not Found" }), { status: 404, headers });
};
export {
  api_default as default
};
